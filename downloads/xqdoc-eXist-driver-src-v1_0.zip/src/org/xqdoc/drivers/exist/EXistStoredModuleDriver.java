package org.xqdoc.drivers.exist;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.exist.xmldb.EXistResource;
import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Resource;
import org.xmldb.api.base.XMLDBException;
import org.xqdoc.conversion.XQDocController;
import org.xqdoc.conversion.XQDocException;
import org.xqdoc.conversion.XQDocPayload;

/*
 *  eXist Open Source Native XML Database
 *  Copyright (C) 2001-04 The eXist Project
 *  http://exist-db.org
 *  
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  $Id$
 */

/**
 * Loads the XQuery sources from a collection on the database instead of the file system.
 * Parses a set of XQuery source documents with xqDoc and stores the generated xqDoc XML into
 * the database collection /db/xqdoc on the eXist server.
 * 
 * The main method expects at least one argument, specifying a path to a database collection on the server
 * that contains one or more XQuery modules. The path will be resolved against the XML:DB root URI. 
 * The stored modules should be binary resources with mime type "application/xquery".
 * 
 * The other arguments are optional:
 * 
 * <ul>
 * <li>the XML:DB URI pointing to the root collection on the database server. By default, this is set
 * to "xmldb:exist://localhost:8080/exist/xmlrpc/db", i.e. the default database URI.</li>
 * <li>the name of the user to connect with.</li>
 * <li>a password for the user.</li>
 * </ul>
 * @author wolf
 *
 */
public class EXistStoredModuleDriver extends EXistAbstractDriver {

    public static void printUsage() {
        System.out.println("\nUsage: " + EXistStoredModuleDriver.class.getName() + 
                " dbCollection [serverURI] [user] [password]\n");
        System.out.println("\tdbCollection: a collection on the db from which to read the module source docs.");
        System.out.println("\tserverURI (optional): the XML:DB URI of the root collection on the server.");
        System.out.println("\tThe default is: 'xmldb:exist://localhost:8080/exist/xmlrpc/db'.");
        System.out.println("\tuser (optional): the user name to connect with. Default is 'guest'.");
        System.out.println("\tpassword (optional): password to use. Default is 'guest'.");
    }
    
    public static void main(String[] args) {
        if (args.length < 1 || args.length > 4) {
            printUsage();
            return;
        }
        
        String xqCollection = args[0];
        String xmldbURI = DEFAULT_URI;
        String user = DEFAULT_USER;
        String pass = DEFAULT_PASS;
        if (args.length > 1)
            xmldbURI = args[1];
        if (args.length > 2)
            user = args[2];
        if (args.length == 4)
            pass = args[3];
        
        // initialize the target collection
        Collection target = null;
        try {
            target = init(xmldbURI, user, pass);
        } catch (Exception e) {
            System.err.println("Failed to initialize database connection: " + e.getMessage());
            return;
        }
        if (target == null) {
            System.err.println("Could not retrieve collection " + xmldbURI);
            return;
        }
        
        if (xmldbURI.endsWith("/db"))
            xmldbURI = xmldbURI.substring(0, xmldbURI.length() - 3);
        System.out.println("Loading from collection " + xmldbURI + xqCollection);
        try {
            Collection source = DatabaseManager.getCollection(xmldbURI + xqCollection);
            if (source == null) {
                System.err.println("Source collection: " + xqCollection + " not found!");
                return;
            }
            
            XQDocController controller = initController();
            
            String resources[] = source.listResources();
            for (int i = 0; i < resources.length; i++) {
                Resource res = source.getResource(resources[i]);
                if ("BinaryResource".equals(res.getResourceType())) {
                    String mime = ((EXistResource) res).getMimeType();
                    if (XQUERY_MIME_TYPE.equals(mime)) {
                        System.out.println("Loading resource " + resources[i]);
                        byte[] data = (byte[]) res.getContent();
                        InputStream istream = new ByteArrayInputStream(data);
                        
                        XQDocPayload payload = controller.process(istream, resources[i]);
                        String moduleURI = payload.getModuleURI();
                        
                        // store the document to the database
                        Resource xqdoc = target.createResource(moduleURI, "XMLResource");
                        xqdoc.setContent(payload.getXQDocXML());
                        target.storeResource(xqdoc);
                    }
                }
            }
        } catch (XMLDBException e) {
            System.err.println("The database reported an error:\n");
            System.err.println(e.getMessage());
            e.printStackTrace();
        } catch (XQDocException e) {
            System.err.println("xqDoc reported an exception:\n");
            System.err.println(e.getMessage());
        }
    }
}
