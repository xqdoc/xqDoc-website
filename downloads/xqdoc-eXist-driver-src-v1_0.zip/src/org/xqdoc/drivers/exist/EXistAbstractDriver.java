/*
 *  eXist Open Source Native XML Database
 *  Copyright (C) 2001-04 The eXist Project
 *  http://exist-db.org
 *  
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  $Id$
 */
package org.xqdoc.drivers.exist;

import java.util.HashMap;

import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Database;
import org.xmldb.api.modules.CollectionManagementService;
import org.xqdoc.conversion.XQDocController;
import org.xqdoc.conversion.XQDocException;

/**
 * @author Wolfgang Meier
 */
public abstract class EXistAbstractDriver {

    protected static final String XQUERY_MIME_TYPE = "application/xquery";
    
    //  Standard XPath F&O prefix and uri
    protected static final String XPATH_PREFIX = "fn";

    protected static final String XPATH_URI = "http://www.w3.org/2003/05/xpath-functions";
    
    protected static final String DEFAULT_USER = "guest";
    protected static final String DEFAULT_PASS = "guest";
    
    protected static final String DEFAULT_URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db";
    
    /**
     * Initialize the database. Creates a collection "/db/xqdoc" if it
     * does not yet exist. This is the collection where the xqdoc XML
     * documents will be stored.
     * 
     * @param uri
     * @param user
     * @param password
     * @return
     * @throws Exception
     */
    protected static Collection init(String uri, String user, String password) throws Exception {
        if (!uri.endsWith("/db"))
            uri = uri + "/db";
        
        Class clazz = Class.forName("org.exist.xmldb.DatabaseImpl");
        Database database = (Database) clazz.newInstance();
        DatabaseManager.registerDatabase(database);
        
        Collection root = DatabaseManager.getCollection(uri);
        Collection collection = root.getChildCollection(XQDocController.COLLECTION);
        if (collection == null) {    
            CollectionManagementService service = (CollectionManagementService)
                root.getService("CollectionManagementService", "1.0");
            collection = service.createCollection(XQDocController.COLLECTION);
        }
        return collection;
    }

    /**
     * Initialize the XQDocController.
     * 
     * @return
     * @throws XQDocException
     */
    protected static XQDocController initController() throws XQDocException {
        // initialize the xqdoc controller and context
        XQDocController controller = new XQDocController(
                XQDocController.NOV2003);
        controller.setEncodeURIs(true);
        HashMap uriMap = new HashMap();
        uriMap.put(XPATH_PREFIX, XPATH_URI);
        controller.setPredefinedFunctionNamespaces(uriMap);
        return controller;
    }
}
