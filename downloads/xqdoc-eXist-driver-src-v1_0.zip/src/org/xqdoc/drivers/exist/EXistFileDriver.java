/*
 *  eXist Open Source Native XML Database
 *  Copyright (C) 2001-04 The eXist Project
 *  http://exist-db.org
 *  
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  $Id$
 */
package org.xqdoc.drivers.exist;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.Writer;

import org.exist.util.MimeTable;
import org.exist.util.MimeType;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Resource;
import org.xmldb.api.base.XMLDBException;
import org.xqdoc.conversion.XQDocController;
import org.xqdoc.conversion.XQDocException;
import org.xqdoc.conversion.XQDocPayload;

/**
 * Parses a set of XQuery files with xqDoc and stores the generated xqDoc XML into
 * the database collection /db/xqdoc on an eXist server.
 * 
 * The main method expects at least one argument, pointing to a single XQuery module file
 * or a directory. If it points to a directory, all XQuery files in the directory and its subdirectories
 * will be processed. If a file is an XQuery file is determined by looking up the file name in
 * eXist's own mime table.
 * 
 * The other arguments are optional:
 * 
 * <ul>
 * <li>the XML:DB URI pointing to the root collection on the database server. By default, this is set
 * to "xmldb:exist://localhost:8080/exist/xmlrpc/db", i.e. the default database URI.</li>
 * <li>the name of the user to connect with.</li>
 * <li>a password for the user.</li>
 * </ul>
 * 
 * @author Wolfgang Meier
 */
public class EXistFileDriver extends EXistAbstractDriver {
    
    public static void printUsage() {
        System.out.println("\nUsage: org.xqdoc.drivers.exist.EXistFileDriver filesOrDir [serverURI] [user] [password]\n");
        System.out.println("\tfilesOrDir: a directory containing XQuery modules or a single XQuery script.");
        System.out.println("\tserverURI (optional): the XML:DB URI of the root collection on the server.");
        System.out.println("\tThe default is: 'xmldb:exist://localhost:8080/exist/xmlrpc/db'.");
        System.out.println("\tuser (optional): the user name to connect with. Default is 'guest'.");
        System.out.println("\tpassword (optional): password to use. Default is 'guest'.");
    }
    
    public static void main(String[] args) {
        if (args.length < 1 || args.length > 4) {
            printUsage();
            return;
        }
        
        String filesOrDir = args[0];
        String xmldbURI = DEFAULT_URI;
        String user = DEFAULT_USER;
        String pass = DEFAULT_PASS;
        if (args.length > 1)
            xmldbURI = args[1];
        if (args.length > 2)
            user = args[2];
        if (args.length == 4)
            pass = args[3];
        
        // initialize the target collection
        Collection collection = null;
        try {
            collection = init(xmldbURI, user, pass);
        } catch (Exception e) {
            System.err.println("Failed to initialize database connection: " + e.getMessage());
            return;
        }
        if (collection == null) {
            System.err.println("Could not retrieve collection " + xmldbURI);
            return;
        }
        
        try {
            XQDocController controller = initController();
            
            // walk through all XQuery files
            String[] files = getFiles(filesOrDir);
            for (int i = 0; i < files.length; i++) {
                System.out.println("Loading " + files[i]);
                try {
                    FileInputStream fstream = new FileInputStream(files[i]);
                    File theFile = new File(files[i]);
                    XQDocPayload payload = controller.process(fstream, theFile
                            .getName());
                    // the XML is stored to a temporary file before loading it into the db
                    File file = File.createTempFile((new File(files[i]))
                            .getName(), null);
                    file.deleteOnExit();
                    Writer outputStream = new FileWriter(file);
                    outputStream.write(payload.getXQDocXML());
                    outputStream.close();
                    String moduleURI = payload.getModuleURI();
                    
                    // store the document to the database
                    Resource resource = collection.createResource(moduleURI, "XMLResource");
                    resource.setContent(file);
                    collection.storeResource(resource);
                    file.delete();
                } catch (XQDocException e) {
                    System.err.println("Error while parsing source file: " + e.getMessage());
                } catch (IOException e) {
                }
            }
        } catch (XQDocException e) {
           System.err.println("xqDoc reported an exception:\n");
           System.err.println(e.getMessage());
        } catch (XMLDBException e) {
            System.err.println("The database reported an exception:\n");
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Get all XQuery modules in the specified path. If a directory
     * has been specified, we use eXist's mime table to check for
     * files that might be XQuery files.
     * 
     * @param path
     * @return
     */
    protected static String[] getFiles(String path) {
        // Check if a file or directory was specified
        File dir = new File(path);
        String[] files = null;
        if (dir.isDirectory()) {
            // dir is a directory ... so get the files
            FilenameFilter filter = new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    MimeType mime = MimeTable.getInstance().getContentTypeFor(name);
                    return mime != null && mime.getName().equals(XQUERY_MIME_TYPE);
                }
            };
            files = dir.list(filter);
            for (int i = 0; i < files.length; i++) {
                files[i] = dir.getPath() + File.separator + files[i];
            }
        } else {
            files = new String[1];
            files[0] = path;
        }
        return files;
    }
}
