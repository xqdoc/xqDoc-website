/*
 *  eXist Open Source Native XML Database
 *  Copyright (C) 2001-04 The eXist Project
 *  http://exist-db.org
 *  
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  $Id$
 */
package org.xqdoc.drivers.exist;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.transform.OutputKeys;

import org.exist.xmldb.XQueryService;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Resource;
import org.xmldb.api.base.ResourceIterator;
import org.xmldb.api.base.ResourceSet;
import org.xmldb.api.base.XMLDBException;

/**
 * This driver generates a .zip file consisting of static XHTML pages
 * representing the xqDoc presentation view of xqDoc XML stored in the 
 * database. 
 * 
 * For this, the xqDoc library module xqdoc-display.xqy needs to be stored in the database
 * as well. The driver assumes that it is stored in the collection "/db/xqdoc".
 * 
 * @author Wolfgang Meier
 */
public class EXistZipDriver extends EXistAbstractDriver {

    private static final String XQDOC_ZIP = "xqdoc.zip";

    private static final String XQDOC_LIB_URI = "xqdoc/xqdoc-display";

    private static final String XQDOC_LIB_LOC = "xmldb:exist:///db/xqdoc/xqdoc-display.xqy";

    public static void printUsage() {
        System.out.println("\nUsage: "
                + EXistZipDriver.class.getName()
                + " outputDir [serverURI] [user] [password]\n");
        System.out
                .println("\toutputDir: an existing directory where the zip file will be written to.");
        System.out
                .println("\tserverURI (optional): the XML:DB URI of the root collection on the server.");
        System.out
                .println("\tThe default is: 'xmldb:exist://localhost:8080/exist/xmlrpc/db'.");
        System.out
                .println("\tuser (optional): the user name to connect with. Default is 'guest'.");
        System.out
                .println("\tpassword (optional): password to use. Default is 'guest'.");
    }

    public static void main(String args[]) {
        if (args.length < 1 || args.length > 4) {
            printUsage();
            return;
        }
        String xmldbURI = DEFAULT_URI;
        String user = DEFAULT_USER;
        String pass = DEFAULT_PASS;
        if (args.length > 1)
            xmldbURI = args[1];
        if (args.length > 2)
            user = args[2];
        if (args.length == 4)
            pass = args[3];

        // connect to the db
        Collection collection = null;
        try {
            collection = init(xmldbURI, user, pass);
        } catch (Exception e) {
            System.err.println("Failed to initialize database connection: "
                    + e.getMessage());
            return;
        }
        if (collection == null) {
            System.err.println("Could not retrieve collection " + xmldbURI);
            return;
        }

        try {
            XQueryService query = (XQueryService) collection.getService(
                    "XQueryService", "1.0");
            query.setProperty(OutputKeys.INDENT, "no");
            
            // Ensure a directory was specifed
            File dir = new File(args[0]);
            boolean isDir = dir.isDirectory();
            if (isDir) {
                // dir is a directory
            } else {
                System.err.println(args[0] + " is not a directory.");
                return;
            }

            // Create zip file in specified directory
            String outFilename = args[0] + File.separator + XQDOC_ZIP;
            ZipOutputStream out = new ZipOutputStream(new FileOutputStream(
                    outFilename));

            // Get a list of modules in the xqdoc collection
            String urisQuery = "import module namespace xq='" + XQDOC_LIB_URI
                    + "' at '" + XQDOC_LIB_LOC + "'; xq:get-module-uris()";
            ResourceSet uris = query.query(urisQuery);

            System.out.println("Modules: " + uris.getSize());

            byte[] bytes = null;

            // Get the default page
            String defaultQuery = "import module namespace xq='"
                    + XQDOC_LIB_URI + "' at '" + XQDOC_LIB_LOC
                    + "'; xq:get-default-html(true())";
            ResourceSet items = query.query(defaultQuery);

            out.putNextEntry(new ZipEntry("default.html"));

            System.out.println("Added --> 'default'");

            for (ResourceIterator i = items.getIterator(); i.hasMoreResources();) {
                Resource next = i.nextResource();
                bytes = ((String) next.getContent()).getBytes("ISO-8859-1");
                out.write(bytes, 0, bytes.length);
            }

            out.closeEntry();

            // Get the module page(s)
            int j = 0;
            for (ResourceIterator i = uris.getIterator(); i.hasMoreResources(); j++) {
                Resource next = i.nextResource();
                String uri = next.getContent().toString();
                String moduleQuery = "import module namespace xq='"
                    + XQDOC_LIB_URI + "' at '" + XQDOC_LIB_LOC
                    + "'; xq:get-module-html('" + uri + "', true())";
                items = query.query(moduleQuery);
                out.putNextEntry(new ZipEntry("xqdoc-file-"
                        + (j + 1) + ".html"));
                for (ResourceIterator k = items.getIterator(); k.hasMoreResources(); ) {
                    next = k.nextResource();
                    bytes = next.getContent().toString().getBytes("ISO-8859-1");
                    out.write(bytes, 0, bytes.length);
                }
                
                System.out.println("Added --> '" + uri + "'");
                out.closeEntry();
                
                String codeQuery = "import module namespace xq='"
                    + XQDOC_LIB_URI + "' at '" + XQDOC_LIB_LOC
                    + "'; xq:get-code-html('" + uri + "',(),true())";
                items = query.query(codeQuery);
                if (items.getSize() > 0) {
                    out.putNextEntry(new ZipEntry("xqdoc-file-"
                            + (j + 1) + "_source.html"));
                    for (ResourceIterator k = items.getIterator(); k.hasMoreResources(); ) {
                        next = k.nextResource();
                        bytes = next.getContent().toString().getBytes("ISO-8859-1");
                        out.write(bytes, 0, bytes.length);
                    }
                }
                out.closeEntry();
                
                // Get the source for the functions
                String listFunctionsQuery = "import module namespace xq='"
                    + XQDOC_LIB_URI + "' at '" + XQDOC_LIB_LOC
                    + "'; xq:get-function-names('" + uri + "')";
                ResourceSet functions = query.query(listFunctionsQuery);
                for (ResourceIterator k = functions.getIterator(); k.hasMoreResources(); ) {
                    String function = k.nextResource().getContent().toString();
                    String functionsQuery = "import module namespace xq='" + XQDOC_LIB_URI + "' at '" + XQDOC_LIB_LOC + "' xq:get-code-html('"
                        + uri + "','" + function + "',true())";
                    items = query.query(codeQuery);
                    if (items.getSize() > 0) {
                        out.putNextEntry(new ZipEntry("xqdoc-file-"
                                + (j + 1) + "-" + function
                                + ".html"));
                        for (ResourceIterator l = items.getIterator(); l.hasMoreResources(); ) {
                            next = l.nextResource();
                            bytes = next.getContent().toString().getBytes("ISO-8859-1");
                            out.write(bytes, 0, bytes.length);
                        }
                        out.closeEntry();
                    } 
                }
            }
            
            out.close();
        } catch (XMLDBException e) {
            System.err.println("The database reported an error:\n");
            System.err.println(e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("An IO error occurred:\n");
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
    }
}
