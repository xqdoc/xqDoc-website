/*
 * Copyright (c)2007 Elsevier, Inc.

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * The use of the Apache License does not indicate that this project is
 * affiliated with the Apache Software Foundation.
 */
package org.xqdoc.lite;

import java.io.*;
import java.util.*;

import org.xqdoc.conversion.*;

import net.sf.saxon.Configuration;
import net.sf.saxon.query.StaticQueryContext;
import net.sf.saxon.query.DynamicQueryContext;
import net.sf.saxon.query.XQueryExpression;
import net.sf.saxon.query.QueryResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import net.sf.saxon.om.*;
import javax.xml.transform.OutputKeys;

public class XQDocLite {

	// Will contain the suffix value specified in the parms for XQDocLite
	public static String SUFFIX;

	// Standard XPath F&O prefix and uri
	protected static final String XPATH_PREFIX = "fn";

	//XPath F&O URI for May 2003
	protected static final String XPATH_MAY2003_URI = "http://www.w3.org/2003/05/xpath-functions";

	//XPath F&O URI for Nov 2003
	protected static final String XPATH_NOV2003_URI = "http://www.w3.org/2003/11/xpath-functions";

	//XPath F&O URI for Oct 2004
	protected static final String XPATH_OCT2004_URI = "http://www.w3.org/2004/10/xpath-functions";

	//XPath F&O URI for Apr 2005
	protected static final String XPATH_APR2005_URI = "http://www.w3.org/2005/04/xpath-functions";

	//XPath F&O URI for Sep 2005
	protected static final String XPATH_SEP2005_URI = "http://www.w3.org/2005/xpath-functions";

	//XPath F&O URI for Nov 2005
	protected static final String XPATH_NOV2005_URI = "http://www.w3.org/2005/xpath-functions";
	
	//XPath F&O URI for Jan 2007
	protected static final String XPATH_JAN2007_URI = "http://www.w3.org/2005/xpath-functions";
	

	/**
	 * This method is used to determine whether an input parameter (arg)
	 * specifies a file or a directory. It will then return an arry of Strings
	 * representing either the file passed in or the list of files (specified by
	 * the directory) which contain a suffix specified in the input parms for
	 * XQDocLite. The enforcement of a suffix value does not apply if only a
	 * filename is specified.
	 * 
	 * @param arg
	 *            Either a filename or a directory name
	 * @return An array of filenames (if anything to process)
	 */
	protected static String[] getFiles(String arg) {
		// Check if a file or directory was specified
		File dir = new File(arg);
		String[] files = null;
		if (dir.isDirectory()) {
			System.out.println("Will process files with a suffix of '"
					+ XQDocLite.SUFFIX + "' in the directory '" + arg + "'");
			// dir is a directory ... so get the files
			FilenameFilter filter = new FilenameFilter() {
				public boolean accept(File dir, String name) {
					return name.endsWith(XQDocLite.SUFFIX);
				}
			};

			files = dir.list((FilenameFilter) filter);
			for (int i = 0; i < files.length; i++) {
				files[i] = dir.getPath() + File.separator + files[i];
			}
		} else if (!dir.exists()) {
			System.out.println("File/Dir specified by '" + arg
					+ "' does not exist.");
		} else {
			System.out.println("Will process the file named '" + arg + "'");
			files = new String[1];
			files[0] = arg;
		}
		return files;
	}

	/**
	 * This method is used to determine whether an input parameter
	 * (xqueryVersion) specifies a valid XQuery specification. If it does, the
	 * string literal for the corresponding version specified in XQDocController
	 * will be returned. If not, a value of 'null' will be returned.
	 * 
	 * @param xqueryVersion
	 *            XQuery version specified in the input parms for XQDocLite
	 * @return The XQuery specification 'literal' from XQDocController
	 */
	protected static String getXQuerySpecification(String xqueryVersion) {
		String xquerySpecification = null;

		if (xqueryVersion.compareTo(XQDocController.MAY2003) == 0)
			xquerySpecification = XQDocController.MAY2003;
		else if (xqueryVersion.compareTo(XQDocController.NOV2003) == 0)
			xquerySpecification = XQDocController.NOV2003;
		else if (xqueryVersion.compareTo(XQDocController.OCT2004) == 0)
			xquerySpecification = XQDocController.OCT2004;
		else if (xqueryVersion.compareTo(XQDocController.APR2005) == 0)
			xquerySpecification = XQDocController.APR2005;
		else if (xqueryVersion.compareTo(XQDocController.SEP2005) == 0)
			xquerySpecification = XQDocController.SEP2005;
		else if (xqueryVersion.compareTo(XQDocController.NOV2005) == 0)
			xquerySpecification = XQDocController.NOV2005;
		else if (xqueryVersion.compareTo(XQDocController.JAN2007) == 0)
			xquerySpecification = XQDocController.JAN2007;	
		else
			xquerySpecification = XQDocController.JAN2007;

		return xquerySpecification;
	}

	/**
	 * This method is used to return the default function namespace URI (for the
	 * XPATH F&O) associated with the XQuery version.
	 * 
	 * @param xquerySpecification
	 *            XQuery specification literal contained in XQDocController
	 * @return The URI for the XPATH F&O associated with the XQuery
	 *         specification
	 */
	protected static String getDefaultFunctionNamespace(
			String xquerySpecification) {
		String defaultFunctionNamespace = null;

		if (xquerySpecification == XQDocController.MAY2003)
			defaultFunctionNamespace = XPATH_MAY2003_URI;
		else if (xquerySpecification == XQDocController.NOV2003)
			defaultFunctionNamespace = XPATH_NOV2003_URI;
		else if (xquerySpecification == XQDocController.OCT2004)
			defaultFunctionNamespace = XPATH_OCT2004_URI;
		else if (xquerySpecification == XQDocController.APR2005)
			defaultFunctionNamespace = XPATH_APR2005_URI;
		else if (xquerySpecification == XQDocController.SEP2005)
			defaultFunctionNamespace = XPATH_SEP2005_URI;
		else if (xquerySpecification == XQDocController.NOV2005)
			defaultFunctionNamespace = XPATH_NOV2005_URI;
		else if (xquerySpecification == XQDocController.JAN2007)
			defaultFunctionNamespace = XPATH_JAN2007_URI;		
		else
			defaultFunctionNamespace = XPATH_JAN2007_URI;

		return defaultFunctionNamespace;
	}

	/**
	 * This method will parse the input parm for XQDocLite, extract the
	 * namespace and prefix mappings, and add them to the HashMap.
	 * 
	 * @param parm
	 *            String of namespace prefix=uri mappings. Each pair will be
	 *            delimited by a semicolon.
	 * @param uriMap
	 *            The HashMap of namespace prefix to uri mappings. The defualt
	 *            function namespace mapping might exist in the map when this
	 *            method is called.
	 * @return The HashMap for the namespace prefix to uri mappings.
	 */
	protected static HashMap getPredefinedFunctionNamespaces(String parm,
			HashMap uriMap) {
		if (parm.compareTo("none") == 0) {
			System.out
					.println("No predefined mapping prefix to namespace uri was specified");
			return uriMap;
		}
		String[] list = parm.split(";");
		for (int i = 0; i < list.length; i++) {
			String[] entry = list[i].split("=");
			if (entry.length != 2) {
				System.out
						.println("Problems mapping prefix to namespace uri ... '"
								+ list[i] + "'");
			} else {
				System.out.println("Prefix '" + entry[0] + "' mapped to '"
						+ entry[1] + "'");
				uriMap.put(entry[0], entry[1]);
			}
		}
		return uriMap;
	}

	/**
	 * Mainline.
	 * 
	 * @param args
	 *            An arry of 6 strings is required.
	 *            <ul>
	 *            <li>File or directory containing module(s) to process</li>
	 *            <li>File extension</li>
	 *            <li>XQuery specification version</li>
	 *            <li>Default function namespace</li>
	 *            <li>Predefined namespace mappings</li>
	 *            <li>Output directory</li>
	 *            </ul>
	 *            or
	 *            <ul>
	 *            <li>Version request</li>
	 *            </ul>
	 */
	public static void main(String args[]) {
		if (args.length == 6 || args.length == 7) {
			File file = null;
			try {
				SUFFIX = args[1];
				String[] files = getFiles(args[0]);
				if (files == null || files.length == 0) {
					// No work to do, so exit.
					System.out.println("No files to process ...");
					return;
				}
				String xquerySpec = getXQuerySpecification(args[2]
						.toLowerCase());
				if (xquerySpec == null) {
					// Unsupported spec version, so exit.
					System.out.println("Invalid XQuery version specified ... '"
							+ args[2] + "'");
					return;
				}
				String xpathURI = getDefaultFunctionNamespace(xquerySpec);
				XQDocController controller = new XQDocController(xquerySpec);

				HashMap uriMap = new HashMap();

				if (args[3].compareTo("default") == 0) {
					System.out.println("Default Function Namespace = '"
							+ xpathURI);
					controller.setDefaultFunctionNamespace(xpathURI);
					System.out.println("Prefix '" + XPATH_PREFIX
							+ "' mapped to '" + xpathURI + "'");
					uriMap.put(XPATH_PREFIX, xpathURI);
				} else {
					System.out.println("Default Function Namespace = '"
							+ args[3] + "'");
					controller.setDefaultFunctionNamespace(args[3]);
					System.out.println("Prefix '" + XPATH_PREFIX
							+ "' mapped to '" + xpathURI + "'");
					uriMap.put(XPATH_PREFIX, xpathURI);
				}

				File outputDir = new File(args[5]);
				if (!outputDir.isDirectory()) {
					System.out.println("The specified output location '"
							+ args[5]
							+ "' doesn't exist or is not a directory.");
					return;
				}

				uriMap = getPredefinedFunctionNamespaces(args[4], uriMap);
				controller.setPredefinedFunctionNamespaces(uriMap);

				// Process each file
				for (int i = 0; i < files.length; i++) {
					FileInputStream fstream = new FileInputStream(files[i]);

					File theFile = new File(files[i]);
					System.out.println("Processing " + theFile.getName());
					XQDocPayload payload = controller.process(fstream, theFile
							.getName());
					file = new File("xqdoc-lite-tmp");
					if (!file.createNewFile()) {
						file.delete();
						file.createNewFile();
					}
					PrintWriter outputStream = new PrintWriter(new FileWriter(
							file));
					outputStream.println(payload.getXQDocXML());
					outputStream.close();

					//----------------------------
					// Begin execute against SAXON
					//----------------------------

					Configuration config = new Configuration();
					StaticQueryContext staticContext = new StaticQueryContext(
							config);
					// Check if an alternate location for the XQuery module was
					// specified by the user. If so, try to use it ...
					// otherwise, use the one contained in the xqdoc_conv.jar.
					XQueryExpression exp = null;
					if (args.length == 7 && new File(args[6]).exists()) {
						exp = staticContext
								.compileQuery(new FileReader(args[6]));
						System.out
								.println("Using the user specified xquery module '"
										+ args[6] + "' to render the output.");
					} else {
						System.out
								.println("Using the default xqdoc-dixplay xquery module to render the output.");
						ClassLoader loader = ClassLoader.getSystemClassLoader();
						InputStream in = loader
								.getResourceAsStream("xqdoc-display.xqy");
						exp = staticContext.compileQuery(in, null);
					}
					DynamicQueryContext dynamicContext = new DynamicQueryContext(
							config);
					dynamicContext.setContextItem(staticContext
							.buildDocument(new StreamSource(file)));
					dynamicContext.setParameter("module", "xqdoc-lite-tmp");
					SequenceIterator books = exp.iterator(dynamicContext);
					Properties props = new Properties();
					props.setProperty(OutputKeys.METHOD, "html");
					props.setProperty(OutputKeys.INDENT, "no");
					props.setProperty(OutputKeys.DOCTYPE_PUBLIC,
							"-//W3C//DTD HTML 4.01 Transitional//EN");

					while (true) {
						NodeInfo book = (NodeInfo) (books.next());
						if (book == null)
							break;
						QueryResult.serialize(book, new StreamResult(new File(
								args[5] + File.separator + theFile.getName()
										+ ".html")), props);
						System.out.println("Created --> '" + theFile.getName()
								+ ".html'");
					}

					//----------------------------
					// End execute against SAXON
					//----------------------------
				}
			} catch (Exception ex) {
				System.out.println(ex.toString());
			} finally {
				if (file != null) {
					try {
						file.delete();
					} catch (Throwable ignore) {
					}
				}
			}
		} else if (args.length == 1 && args[0].compareTo("-version") == 0) {
			ClassLoader loader = null;
			InputStream in = null;
			try {
				loader = ClassLoader.getSystemClassLoader();
				in = loader.getResourceAsStream("xqdoc-build-info");
				if (in == null)
					throw new Exception(
							"Could not locate xqdoc-build-info file.");
				StringBuffer sb = new StringBuffer();
				for (int i = in.read(); i != -1; i = in.read()) {
					sb.append((char) i);
				}
				System.out.println(sb.toString());
			} catch (Exception ex) {
				System.out.println("Problems obtaining xqDoc build version: "
						+ ex.toString());
			} finally {
				if (in != null)
					try {
						in.close();
					} catch (Throwable ignore) {
					}
			}
		} else {
			System.out.println("System usage is as follows:");
			System.out
					.println("    XQDocLite  [file | dir] [file-extension] [xquery-version] [default-function-namespace] [pre-defined-namespace-mapping] [output-directory] [xqdoc-display]");
			System.out.println("     OR ");
			System.out.println("    XQDocLite -version");
			System.out.println("");
			System.out
					.println("    file --> individual xquery library module to process");
			System.out
					.println("    dir --> directory containing library modules to process");
			System.out
					.println("    file-extension --> XQuery file extension (i.e. xq, xqy, etc.)");
			System.out
					.println("    xquery-version --> XQuery specification version (MAY2003, NOV2003, OCT2004, APR2005, SEP2005, NOV2005)");
			System.out
					.println("    default-function-namespace --> A URI value or 'default' to use the XPATH F&O");
			System.out
					.println("    predefined-namespace-mappings --> semi-colon separated list of prefix=uri mappings or 'none'");
			System.out
					.println("    output-directory --> directory for outputting the xqDoc xml and xhtml files");
			System.out
					.println("    xqdoc-display --> Location of the xquery module to render the output (optional)");
			System.out
					.println("    -version --> outputs the version and build information for xqDoc.");

		}

	}
}