/*
 * Copyright (c)2005 Elsevier, Inc.

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * The use of the Apache License does not indicate that this project is
 * affiliated with the Apache Software Foundation.
 */

package org.xqdoc.drivers.marklogic;

/**
 * This driver loads generated xqDoc XML for both main modules and library
 * modules contained in a filesystem into the MarkLogic database. Using
 * supporting classes, this driver will read and parse the module(s), generate
 * xqDoc XML, and store this XML into the MarkLogic database. The original
 * module(s) in the filesystem will remain unchanged.
 * 
 * @author Darin McBeath
 * @version 1.0
 */
import java.io.*;
import java.util.*;
import org.xqdoc.conversion.*;

public class MarkLogicFileDriver extends MarkLogicDriver {

	/**
	 * This is the mainline for loading files into the MarkLogic database.
	 * Either a single module can be processesd or an entire directory of
	 * modules can be processed. The XQuery W3C Working Draft version is set to
	 * 'may2003' to indicate which grammar to use when parsing the modules. The
	 * XQDocPayload returned from the XQDocController process() method will
	 * contain both the serialized xqDoc XML and the xqDoc URI associated with
	 * this XML. This serialized XML will be inserted into the MarkLogic
	 * database under the 'xqdoc' collection with the associated uri.
	 * 
	 * @param args
	 *            An arry of 5 strings is required.
	 *            <ul>
	 *            <li>File name or directory containing module(s) to process.
	 *            </li>
	 *            <li>The hostname for the MarkLogic XDBC server.</li>
	 *            <li>The port number for the MarkLogic XDBC server.</li>
	 *            <li>The username for the MarkLogic XDBC server.</li>
	 *            <li>The password for the MarkLogic XDBC server.</li>
	 *            </ul>
	 */
	public static void main(String args[]) {
		if (args.length == 5) {

			String[] files = getFiles(args[0]);
			HOST_OUTPUT = args[1];
			PORT_OUTPUT = Integer.parseInt(args[2]);
			USERNAME_OUTPUT = args[3];
			PASSWORD_OUTPUT = args[4];

			try {
				XQDocController controller = new XQDocController(
						XQDocController.MAY2003);

				HashMap uriMap = new HashMap();
				uriMap.put(CTS_PREFIX, CTS_URI);
				uriMap.put(XDMP_PREFIX, XDMP_URI);
				uriMap.put(XPATH_PREFIX, XPATH_URI);
				controller.setPredefinedFunctionNamespaces(uriMap);
			
				//controller.setEncodeURIs(true);
				
				for (int i = 0; i < files.length; i++) {
					FileInputStream fstream = new FileInputStream(files[i]);

					File theFile = new File(files[i]);
					XQDocPayload payload = controller.process(fstream, theFile
							.getName());
					File file = File.createTempFile((new File(files[i]))
							.getName(), null);
					file.deleteOnExit();
					PrintWriter outputStream = new PrintWriter(new FileWriter(
							file));
					outputStream.println(payload.getXQDocXML());
					outputStream.close();

					createOutputDataSource();
					String loadQuery = "xdmp:load('" + file.getPath() + "','"
							+ payload.getModuleURI() + "',(),('"
							+ XQDocController.COLLECTION + "'),0,'','format-xml')";

					executeOutput(loadQuery);

					System.out.println("Inserted --> '"
							+ payload.getModuleURI() + "'");

				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		} else {
			System.out.println("System usage is as follows:");
			System.out
					.println("  MarkLogicFileDriver  [file | dir] [host] [port] [username] [password]");
			System.out
					.println("    file     individual xquery library module to process");
			System.out
					.println("    dir      directory containing library modules to process");
			System.out.println("    host     hostname for the xdbc server");
			System.out.println("    port     port number for the xdbc server");
			System.out.println("    username username for the xdbc server");
			System.out.println("    password password for the xdbc server");

		}

	}
}

