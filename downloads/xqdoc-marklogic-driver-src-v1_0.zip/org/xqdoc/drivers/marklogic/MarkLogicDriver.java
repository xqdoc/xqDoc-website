/*
 * Copyright (c)2005 Elsevier, Inc.

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * The use of the Apache License does not indicate that this project is
 * affiliated with the Apache Software Foundation.
 */

package org.xqdoc.drivers.marklogic;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

import com.marklogic.xqrunner.XQDataSource;
import com.marklogic.xqrunner.XQFactory;
import com.marklogic.xqrunner.XQResult;
import com.marklogic.xqrunner.XQResultItem;
import com.marklogic.xqrunner.XQRunner;
import com.marklogic.xqrunner.XQException;

import org.xqdoc.conversion.XQDocException;

/**
 * This abstract class is the the base class for the other MarkLogic drivers.
 * This class contains static constants (i.e. for MarkLogic predefined function
 * namespaces) and helper methods for processing files or interacting with the
 * MarkLogic database.
 * 
 * @author Dmcbeath
 * @version 1.0
 */
public abstract class MarkLogicDriver {

	// The following are predefined for MarkLogic proprietary extensions
	protected static final String CTS_PREFIX = "cts";

	protected static final String CTS_URI = "http://marklogic.com/cts";

	protected static final String XDMP_PREFIX = "xdmp";

	protected static final String XDMP_URI = "http://marklogic.com/xdmp";

	// Standard XPath F&O prefix and uri
	protected static final String XPATH_PREFIX = "fn";

	protected static final String XPATH_URI = "http://www.w3.org/2003/05/xpath-functions";

	// File suffix for XQuery files
	protected static final String XQUERY_FILE_SUFFIX = ".xqy";

	protected static String HOST_INPUT;

	protected static int PORT_INPUT;

	protected static String USERNAME_INPUT;

	protected static String PASSWORD_INPUT;

	protected static String HOST_OUTPUT;

	protected static int PORT_OUTPUT;

	protected static String USERNAME_OUTPUT;

	protected static String PASSWORD_OUTPUT;

	private static XQDataSource dataSource_input;

	private static XQRunner runner_input;

	private static XQDataSource dataSource_output;

	private static XQRunner runner_output;

	/**
	 * This method is used to determine whether an input parameter (arg)
	 * specifies a file or a directory. It will then return an arry of Strings
	 * representing either the file passed in or the list of files (specified by
	 * the directory) which contain a suffix of ".xqy". The enforcement of a
	 * ".xqy" does not apply if only a filename is specified.
	 * 
	 * @param arg
	 *            Either a filename or a directory name
	 * @return An array of filenames
	 */
	protected static String[] getFiles(String arg) {
		// Check if a file or directory was specified
		File dir = new File(arg);
		String[] files = null;
		if (dir.isDirectory()) {
			// dir is a directory ... so get the files
			FilenameFilter filter = new FilenameFilter() {
				public boolean accept(File dir, String name) {
					return name.endsWith(XQUERY_FILE_SUFFIX);
				}
			};
			files = dir.list(filter);
			for (int i = 0; i < files.length; i++) {
				files[i] = dir.getPath() + File.separator + files[i];
			}
		} else {
			files = new String[1];
			files[0] = arg;
		}
		return files;
	}

	/**
	 * Create a MarkLogic input data source with the specified values. The input
	 * data source is used when 'reading' a module that is stored in the
	 * MarkLogic 'modules' database. This module will then be parsed to create
	 * xqDoc XML that will then be stored back into the MarkLogic database
	 * (using the output data source). The input data source is also used by the
	 * zip driver to retrieve the results of XQuery executed against the
	 * MarkLogic database.
	 * 
	 * @param host
	 *            MarkLogic XDBC server host name
	 * @param port
	 *            MarkLogic XDBC server port number
	 * @param username
	 *            MarkLogic XDBC server username
	 * @param password
	 *            MarkLogic XDBC server password
	 * @throws XQDocException
	 */
	protected static void createInputDataSource(String host, int port,
			String username, String password) throws XQDocException {
		try {
			XQFactory factory = new XQFactory();
			dataSource_input = factory.newDataSource(host, port, username,
					password);
			runner_input = dataSource_input.newSyncRunner();
		} catch (XQException ex) {
			throw new XQDocException(ex);
		}
	}

	/**
	 * Create a MarkLogic input data source based on previously set values. The
	 * input data source is used when 'reading' a module that is stored in the
	 * MarkLogic 'modules' database. This module will then be parsed to create
	 * xqDoc XML that will then be stored back into the MarkLogic database
	 * (using the output data source). The input data source is also used by the
	 * zip driver to retrieve the results of XQuery executed against the
	 * MarkLogic database.
	 * 
	 * @throws XQDocException
	 */
	protected static void createInputDataSource() throws XQDocException {
		createInputDataSource(HOST_INPUT, PORT_INPUT, USERNAME_INPUT,
				PASSWORD_INPUT);
	}

	/**
	 * Execute a query (a string of XQuery) against the input data source.
	 * 
	 * @param query
	 *            A String of XQuery.
	 * @return The result of the query (a sequence of items) returned as a List
	 *         of strings
	 * @throws XQDocException
	 */
	protected static List executeInput(String query) throws XQDocException {
		try {
			XQResult result = runner_input.runQuery(dataSource_input
					.newQuery(query));
			XQResultItem items[] = result.getItems();

			ArrayList list = new ArrayList();
			for (int i = 0; i < items.length; i++) {
				list.add(items[i].asString());
			}
			return list;
		} catch (XQException ex) {
			throw new XQDocException(ex);
		}
	}

	/**
	 * Create a MarkLogic output data source with the specified values. The
	 * output data source is used to store xqDoc XML into the MarkLogic
	 * database.
	 * 
	 * @param host
	 *            MarkLogic XDBC server host name
	 * @param port
	 *            MarkLogic XDBC server port number
	 * @param username
	 *            MarkLogic XDBC server username
	 * @param password
	 *            MarkLogic XDBC server password
	 * @throws XQDocException
	 */
	protected static void createOutputDataSource(String host, int port,
			String username, String password) throws XQDocException {
		try {
			XQFactory factory = new XQFactory();
			dataSource_output = factory.newDataSource(host, port, username,
					password);
			runner_output = dataSource_output.newSyncRunner();
		} catch (XQException ex) {
			throw new XQDocException(ex);
		}
	}

	/**
	 * Create a MarkLogic output data source based on previously set values. The
	 * output data source is used to store xqDoc XML into the MarkLogic
	 * database.
	 * 
	 * @throws XQDocException
	 */
	protected static void createOutputDataSource() throws XQDocException {
		createOutputDataSource(HOST_OUTPUT, PORT_OUTPUT, USERNAME_OUTPUT,
				PASSWORD_OUTPUT);
	}

	/**
	 * Execute a query (a string of XQuery) against the output data source.
	 * 
	 * @param query
	 *            A String of XQuery.
	 * @return The result of the query (a sequence of items) returned as a List
	 *         of strings
	 * @throws XQDocException
	 */
	protected static List executeOutput(String query) throws XQDocException {
		try {
			XQResult result = runner_output.runQuery(dataSource_output
					.newQuery(query));
			XQResultItem items[] = result.getItems();

			ArrayList list = new ArrayList();
			for (int i = 0; i < items.length; i++) {
				list.add(items[i].asString());
			}
			return list;
		} catch (XQException ex) {
			throw new XQDocException(ex);
		}
	}
}