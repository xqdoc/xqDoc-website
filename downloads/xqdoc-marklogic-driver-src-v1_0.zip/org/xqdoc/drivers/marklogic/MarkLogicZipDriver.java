/*
 * Copyright (c)2005 Elsevier, Inc.

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * The use of the Apache License does not indicate that this project is
 * affiliated with the Apache Software Foundation.
 */

package org.xqdoc.drivers.marklogic;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.xqdoc.conversion.XQDocException;

/**
 * This driver generates a .zip file consisting of static XHTML pages
 * representing the xqDoc presentation view of xqDoc XML stored in the MarkLogic
 * database. This has the advantage that once the .zip file is generated, the
 * viewer of the XHTML contained in the .zip file does not need access to the
 * MarkLogic XML database. Of course, changes made to the xqDoc XML contained in
 * the database (after the .zip file is created) will not be represented in the
 * XHTML presentation view.
 * 
 * @author Darin McBeath
 * @version 1.0
 */
public class MarkLogicZipDriver extends MarkLogicDriver {

	private static final String XQDOC_LIB_URI = "xqdoc/xqdoc-display";
	private static final String XQDOC_LIB_LOC = "xqdoc-display.xqy";
	private static final String XQDOC_ZIP = "xqdoc.zip";
	
	/**
	 * This is the mainline for creating the xqdoc.zip file. The following
	 * queries will be issued against the MarkLogic XML database to retrieve the
	 * necessary information for insertion into xqdoc.zip file.
	 * <ul>
	 * <li>Get the default or homepage for xqDoc.</li>
	 * <li>Get the list of modules.</li>
	 * <li>Get the source code for each module.</li>
	 * <li>Get the xqDoc presentation page for each module.</li>
	 * <li>Get the list of functions for each module.</li>
	 * <li>Get the source code for each function.</li>
	 * </ul>
	 * 
	 * @param args
	 *            An arry of 5 strings is required.
	 *            <ul>
	 *            <li>Where to place the generated xqdoc zip file.</li>
	 *            <li>The hostname for the MarkLogic XDBC server.</li>
	 *            <li>The port number for the MarkLogic XDBC server.</li>
	 *            <li>The username for the MarkLogic XDBC server.</li>
	 *            <li>The password for the MarkLogic XDBC server.</li>
	 *            </ul>
	 */
	public static void main(String args[]) {
		if (args.length == 5) {

			HOST_INPUT = args[1];
			PORT_INPUT = Integer.parseInt(args[2]);
			USERNAME_INPUT = args[3];
			PASSWORD_INPUT = args[4];

			try {
				// Ensure a directory was specifed
				File dir = new File(args[0]);
				boolean isDir = dir.isDirectory();
				if (isDir) {
					// dir is a directory
				} else {
					throw (new XQDocException(args[0] + " is not a directory."));
				}

				// Create zip file in specified directory
				String outFilename = args[0] + File.separator + XQDOC_ZIP;
				ZipOutputStream out = new ZipOutputStream(new FileOutputStream(
						outFilename));

				// Get a list of modules in the xqdoc collection
				createInputDataSource();
				String urisQuery = "import module namespace xq='" + XQDOC_LIB_URI + "' at '" + XQDOC_LIB_LOC + "' xq:get-module-uris()";
				List uris = executeInput(urisQuery);

				byte[] bytes = null;

				// Get the default page
				String defaultQuery = "import module namespace xq='" + XQDOC_LIB_URI + "' at '" + XQDOC_LIB_LOC + "' xq:get-default-html(true())";
				List items = executeInput(defaultQuery);

				out.putNextEntry(new ZipEntry("default.html"));

				System.out.println("Added --> 'default'");

				for (int i = 0; i < items.size(); i++) {
					bytes = ((String) items.get(i)).getBytes();
					out.write(bytes, 0, bytes.length);
				}

				out.closeEntry();

				// Get the module page(s)
				Iterator it = uris.iterator();
				while (it.hasNext()) {
					String uri = (String) it.next();
					String moduleQuery = "import module namespace xq='" + XQDOC_LIB_URI + "' at '" + XQDOC_LIB_LOC + "' xq:get-module-html('"
							+ uri + "',true())";
					items = executeInput(moduleQuery);

					out.putNextEntry(new ZipEntry("xqdoc-file-"
							+ (uris.indexOf(uri) + 1) + ".html"));

					for (int i = 0; i < items.size(); i++) {
						bytes = ((String) items.get(i)).getBytes();
						out.write(bytes, 0, bytes.length);
					}

					System.out.println("Added --> '" + uri + "'");

					out.closeEntry();

					// Get the source for the entire module
					String moduleSourceQuery = "import module namespace xq='" + XQDOC_LIB_URI + "' at '" + XQDOC_LIB_LOC + "' xq:get-code-html('"
							+ uri + "',(),true())";
					items = executeInput(moduleSourceQuery);
					if (items.size() > 0) {
						out.putNextEntry(new ZipEntry("xqdoc-file-"
								+ (uris.indexOf(uri) + 1) + "_source.html"));

						for (int i = 0; i < items.size(); i++) {
							bytes = ((String) items.get(i)).getBytes();
							out.write(bytes, 0, bytes.length);
						}

						System.out.println("Added --> '" + uri + " source'");

						out.closeEntry();

					}

					// Get the source for the functions
					String functionNamesQuery = "import module namespace xq='" + XQDOC_LIB_URI + "' at '" + XQDOC_LIB_LOC + "' xq:get-function-names('"
							+ uri + "')";
					List functionNames = executeInput(functionNamesQuery);

					Iterator functions = functionNames.iterator();
					while (functions.hasNext()) {
						String function = (String) functions.next();
						String functionsQuery = "import module namespace xq='" + XQDOC_LIB_URI + "' at '" + XQDOC_LIB_LOC + "' xq:get-code-html('"
								+ uri + "','" + function + "',true())";
						items = executeInput(functionsQuery);

						if (items.size() > 0) {
							out.putNextEntry(new ZipEntry("xqdoc-file-"
									+ (uris.indexOf(uri) + 1) + "-" + function
									+ ".html"));

							for (int i = 0; i < items.size(); i++) {
								bytes = ((String) items.get(i)).getBytes();
								out.write(bytes, 0, bytes.length);
							}

							System.out.println("Added --> '" + uri + "-"
									+ function + "'");

							out.closeEntry();
						}
					}

				}

				out.close();

			} catch (Exception ex) {
				ex.printStackTrace();
			}

		} else {
			System.out.println("System usage is as follows:");
			System.out
					.println("  MarkLogicZipDriver [zip-file location] [host] [port] [username] [password]");
			System.out.println("    the place to put the xqdoc zip file");
			System.out.println("    host     hostname for the xdbc server");
			System.out.println("    port     port number for the xdbc server");
			System.out.println("    username username for the xdbc server");
			System.out.println("    password password for the xdbc server");

		}

	}
}

