// $ANTLR 2.7.5 (20050201): "XQuery.g" -> "XQueryParser.java"$

	
/**  
 * Grammar definition for the November 2005 XQuery specification.
 */
	package org.xqdoc.xquery.parser.jan2007;

	import antlr.debug.misc.*;
	import java.io.StringReader;
	import java.io.BufferedReader;
	import java.io.InputStreamReader;
	import java.util.ArrayList;
	import java.util.HashSet;
	import java.util.List;
	import java.util.Iterator;
	import java.util.Stack;

	import org.xqdoc.conversion.XQDocContext;

public interface XQueryParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int LITERAL_xquery = 4;
	int LITERAL_version = 5;
	int LITERAL_module = 6;
	int LITERAL_namespace = 7;
	int STRING_LITERAL = 8;
	int LITERAL_encoding = 9;
	int EQ = 10;
	int LITERAL_declare = 11;
	// "boundary-space" = 12
	int LITERAL_default = 13;
	int LITERAL_collation = 14;
	// "base-uri" = 15
	int LITERAL_construction = 16;
	int LITERAL_ordering = 17;
	int LITERAL_order = 18;
	// "copy-namespaces" = 19
	int LITERAL_import = 20;
	int LITERAL_schema = 21;
	int LITERAL_element = 22;
	int LITERAL_function = 23;
	int LITERAL_variable = 24;
	int LITERAL_option = 25;
	int SEMICOLON = 26;
	int LITERAL_preserve = 27;
	int LITERAL_strip = 28;
	int LITERAL_ordered = 29;
	int LITERAL_unordered = 30;
	int LITERAL_empty = 31;
	int LITERAL_greatest = 32;
	int LITERAL_least = 33;
	// "no-preserve" = 34
	int COMMA = 35;
	int LITERAL_inherit = 36;
	// "no-inherit" = 37
	int LITERAL_at = 38;
	int DOLLAR = 39;
	int COLON = 40;
	int LITERAL_external = 41;
	int LPAREN = 42;
	int RPAREN = 43;
	int LITERAL_as = 44;
	int LCURLY = 45;
	int RCURLY = 46;
	int LITERAL_for = 47;
	int LITERAL_let = 48;
	int LITERAL_some = 49;
	int LITERAL_every = 50;
	int LITERAL_typeswitch = 51;
	int LITERAL_update = 52;
	int LITERAL_replace = 53;
	int LITERAL_value = 54;
	int LITERAL_insert = 55;
	int LITERAL_delete = 56;
	int LITERAL_rename = 57;
	int LITERAL_if = 58;
	int LITERAL_try = 59;
	int LITERAL_catch = 60;
	int LITERAL_with = 61;
	int LITERAL_into = 62;
	int LITERAL_preceding = 63;
	int LITERAL_following = 64;
	int LITERAL_return = 65;
	int LITERAL_in = 66;
	int LITERAL_where = 67;
	int LITERAL_stable = 68;
	int LITERAL_by = 69;
	int LITERAL_ascending = 70;
	int LITERAL_descending = 71;
	int LITERAL_satisfies = 72;
	int LITERAL_case = 73;
	int LITERAL_then = 74;
	int LITERAL_else = 75;
	int LITERAL_or = 76;
	int LITERAL_and = 77;
	int LT = 78;
	int GT = 79;
	int LITERAL_eq = 80;
	int LITERAL_ne = 81;
	int LITERAL_lt = 82;
	int LITERAL_le = 83;
	int LITERAL_gt = 84;
	int LITERAL_ge = 85;
	int NEQ = 86;
	int GTEQ = 87;
	int LTEQ = 88;
	int LITERAL_is = 89;
	int LITERAL_to = 90;
	int PLUS = 91;
	int MINUS = 92;
	int STAR = 93;
	int LITERAL_div = 94;
	int LITERAL_idiv = 95;
	int LITERAL_mod = 96;
	int LITERAL_union = 97;
	int UNION = 98;
	int LITERAL_intersect = 99;
	int LITERAL_except = 100;
	int LITERAL_instance = 101;
	int LITERAL_of = 102;
	int LITERAL_treat = 103;
	int LITERAL_castable = 104;
	int LITERAL_cast = 105;
	int LITERAL_validate = 106;
	int PRAGMA = 107;
	int SLASH = 108;
	int DSLASH = 109;
	int LITERAL_text = 110;
	int LITERAL_node = 111;
	int LITERAL_attribute = 112;
	int LITERAL_comment = 113;
	// "processing-instruction" = 114
	// "document-node" = 115
	// "schema-attribute" = 116
	// "schema-element" = 117
	int LITERAL_document = 118;
	int SELF = 119;
	int XML_COMMENT = 120;
	int XML_PI = 121;
	int AT = 122;
	int PARENT = 123;
	int LITERAL_child = 124;
	int LITERAL_self = 125;
	int LITERAL_descendant = 126;
	// "descendant-or-self" = 127
	// "following-sibling" = 128
	int LITERAL_parent = 129;
	int LITERAL_ancestor = 130;
	// "ancestor-or-self" = 131
	// "preceding-sibling" = 132
	int LPPAREN = 133;
	int RPPAREN = 134;
	int DOUBLE_LITERAL = 135;
	int DECIMAL_LITERAL = 136;
	int INTEGER_LITERAL = 137;
	int END_TAG_START = 138;
	int ELEMENT_CONTENT = 139;
	int QUOT = 140;
	int APOS = 141;
	int QUOT_ATTRIBUTE_CONTENT = 142;
	int APOS_ATTRIBUTE_CONTENT = 143;
	int XQDOC_COMMENT = 144;
	int XML_COMMENT_END = 145;
	int XML_PI_END = 146;
	int XML_CDATA = 147;
	int XML_CDATA_END = 148;
	int QUESTION = 149;
	// "empty-sequence" = 150
	int LITERAL_item = 151;
	int NCNAME = 152;
	int LITERAL_lax = 153;
	int LITERAL_strict = 154;
	int ANDEQ = 155;
	int OREQ = 156;
	int XML_PI_START = 157;
	int LETTER = 158;
	int DIGITS = 159;
	int HEX_DIGITS = 160;
	int NMSTART = 161;
	int NMCHAR = 162;
	int WS = 163;
	int EXPR_COMMENT = 164;
	int PRAGMA_CONTENT = 165;
	int PRAGMA_QNAME = 166;
	int PREDEFINED_ENTITY_REF = 167;
	int CHAR_REF = 168;
	int NEXT_TOKEN = 169;
	int CHAR = 170;
	int BASECHAR = 171;
	int IDEOGRAPHIC = 172;
	int COMBINING_CHAR = 173;
	int DIGIT = 174;
	int EXTENDER = 175;
}
